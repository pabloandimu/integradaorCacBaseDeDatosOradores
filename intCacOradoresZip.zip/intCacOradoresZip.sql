-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.1.0 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla integrador_cac.oradores: ~10 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Ana', 'Rodriguez', 'anarodri@gmail.com', 'Base de datos', '2023-11-11 14:12:08'),
	(2, 'Belén', 'Garcia', 'belengarcia@gmail.com', 'Front-End', '2023-11-11 15:19:28'),
	(3, 'Carlos', 'Cepeda', 'carloscepeda@gmail.com', 'Javascript', '2023-11-11 15:19:49'),
	(4, 'Daniela', 'Grossman', 'danielagros@gmail.com', 'Java', '2023-11-11 15:20:20'),
	(5, 'Estela', 'Mora', 'estellitamorada@gmail.com', 'Back-End', '2023-11-11 15:20:56'),
	(6, 'Facundo', 'Rosales', 'facarosales@hotmail.com', 'Mejor lenguaje de programación', '2023-11-11 15:21:35'),
	(7, 'Gabriela', 'Condori', 'gabicon@gmail.com', 'Node JS', '2023-11-11 15:22:01'),
	(8, 'Horacio', 'Campanella', 'horaciocampi@gmail.com', 'Librerías y Framekorks', '2023-11-11 15:22:39'),
	(9, 'Inés', 'Moscarelli', 'inesitalinda@yahoo.com.ar', 'Lenguajes 2023', '2023-11-11 15:23:22'),
	(10, 'Jacinto', 'Correa', 'titocorrer@gmail.com', 'Lenguajes para edición online de audio', '2023-11-11 15:24:18');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
